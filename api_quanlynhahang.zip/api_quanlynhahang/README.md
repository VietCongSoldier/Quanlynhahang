#project api_quanlynhahang by Tuyen
##Technologies
- ASP.NET CORE
##package
- Micrsoft.EntityFrameworkCore.Sqlserve
- Micrsoft.EntityFrameworkCore.Design
- Micrsoft.EntityFrameworkCore.Tools
- Micrsoft.Extensions.Configuration.FileExtensions
- Micrsoft.Extensions.Configuration.Json
- Microsft.AspNetCore.Identyti.EntityFrameworkCore