﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Data.Migrations
{
    public partial class update20201111 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_chitietdonhangs_monans_idmon",
                table: "chitietdonhangs");

            migrationBuilder.DropIndex(
                name: "IX_chitietdonhangs_idmon",
                table: "chitietdonhangs");

            migrationBuilder.AlterColumn<DateTime>(
                name: "ngaydat",
                table: "donhang",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "approles",
                keyColumn: "Id",
                keyValue: new Guid("dde4ba55-808e-479f-be8b-72f69913442f"),
                column: "ConcurrencyStamp",
                value: "fcbfd9a6-9dd7-45d4-8d26-8f36bcf202c1");

            migrationBuilder.UpdateData(
                table: "appusers",
                keyColumn: "Id",
                keyValue: new Guid("06e12df2-49ec-4f5a-9d45-fd714ebca62e"),
                columns: new[] { "ConcurrencyStamp", "PasswordHash" },
                values: new object[] { "53021045-c5cf-4925-af50-8ca884969f94", "AQAAAAEAACcQAAAAEHEM30LKlYYJNYwJC4/8Wl4Yw3oQADtYw4V9Y2axnow6nFYDyzQyybvINDT0FZGCiA==" });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 1,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 11, 1, 58, 32, 242, DateTimeKind.Local).AddTicks(340) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 2,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 11, 1, 58, 32, 242, DateTimeKind.Local).AddTicks(2189) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 3,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 11, 1, 58, 32, 242, DateTimeKind.Local).AddTicks(2222) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 4,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 11, 1, 58, 32, 242, DateTimeKind.Local).AddTicks(2227) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 5,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 11, 1, 58, 32, 242, DateTimeKind.Local).AddTicks(2230) });

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 1,
                column: "gianhap",
                value: new DateTime(2020, 11, 11, 1, 58, 32, 239, DateTimeKind.Local).AddTicks(7752));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 2,
                column: "gianhap",
                value: new DateTime(2020, 11, 11, 1, 58, 32, 241, DateTimeKind.Local).AddTicks(1730));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 3,
                column: "gianhap",
                value: new DateTime(2020, 11, 11, 1, 58, 32, 241, DateTimeKind.Local).AddTicks(1787));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 4,
                column: "gianhap",
                value: new DateTime(2020, 11, 11, 1, 58, 32, 241, DateTimeKind.Local).AddTicks(1793));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "ngaydat",
                table: "donhang",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime));

            migrationBuilder.UpdateData(
                table: "approles",
                keyColumn: "Id",
                keyValue: new Guid("dde4ba55-808e-479f-be8b-72f69913442f"),
                column: "ConcurrencyStamp",
                value: "7df4f68d-655b-455e-819e-71207b240017");

            migrationBuilder.UpdateData(
                table: "appusers",
                keyColumn: "Id",
                keyValue: new Guid("06e12df2-49ec-4f5a-9d45-fd714ebca62e"),
                columns: new[] { "ConcurrencyStamp", "PasswordHash" },
                values: new object[] { "38518a73-fd98-43a4-bcaa-1eb865951e02", "AQAAAAEAACcQAAAAEN5JR+UbWSLe3ycElqH9KtbO0ZmReoUG1uEwCuKIljs1Ovrlenbf0tFRFLyIpythOQ==" });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 1,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 10, 20, 43, 45, 899, DateTimeKind.Local).AddTicks(8816) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 2,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 10, 20, 43, 45, 899, DateTimeKind.Local).AddTicks(9422) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 3,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 10, 20, 43, 45, 899, DateTimeKind.Local).AddTicks(9435) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 4,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 10, 20, 43, 45, 899, DateTimeKind.Local).AddTicks(9437) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 5,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 10, 20, 43, 45, 899, DateTimeKind.Local).AddTicks(9439) });

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 1,
                column: "gianhap",
                value: new DateTime(2020, 11, 10, 20, 43, 45, 898, DateTimeKind.Local).AddTicks(2758));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 2,
                column: "gianhap",
                value: new DateTime(2020, 11, 10, 20, 43, 45, 899, DateTimeKind.Local).AddTicks(2633));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 3,
                column: "gianhap",
                value: new DateTime(2020, 11, 10, 20, 43, 45, 899, DateTimeKind.Local).AddTicks(2677));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 4,
                column: "gianhap",
                value: new DateTime(2020, 11, 10, 20, 43, 45, 899, DateTimeKind.Local).AddTicks(2681));

            migrationBuilder.CreateIndex(
                name: "IX_chitietdonhangs_idmon",
                table: "chitietdonhangs",
                column: "idmon",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_chitietdonhangs_monans_idmon",
                table: "chitietdonhangs",
                column: "idmon",
                principalTable: "monans",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
