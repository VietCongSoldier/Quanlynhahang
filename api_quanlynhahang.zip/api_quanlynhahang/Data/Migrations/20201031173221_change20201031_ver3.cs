﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Data.Migrations
{
    public partial class change20201031_ver3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "rate",
                table: "monans",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.UpdateData(
                table: "approles",
                keyColumn: "Id",
                keyValue: new Guid("dde4ba55-808e-479f-be8b-72f69913442f"),
                column: "ConcurrencyStamp",
                value: "bf156de3-3ee8-48a3-9b0b-0362c7de91fb");

            migrationBuilder.UpdateData(
                table: "appusers",
                keyColumn: "Id",
                keyValue: new Guid("06e12df2-49ec-4f5a-9d45-fd714ebca62e"),
                columns: new[] { "ConcurrencyStamp", "PasswordHash" },
                values: new object[] { "c76d304c-5a67-4371-8028-1d95ddc2ad74", "AQAAAAEAACcQAAAAEOSoZ6sp4IsuJMyR3pIqF6rb5Qr2YjfX5eu/TQBfm2/cf+kHqfk9us32OF3SNROV2A==" });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 1,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 1, 0, 32, 17, 562, DateTimeKind.Local).AddTicks(5782) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 2,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 1, 0, 32, 17, 562, DateTimeKind.Local).AddTicks(6432) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 3,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 1, 0, 32, 17, 562, DateTimeKind.Local).AddTicks(6446) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 4,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 1, 0, 32, 17, 562, DateTimeKind.Local).AddTicks(6448) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 5,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 1, 0, 32, 17, 562, DateTimeKind.Local).AddTicks(6450) });

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 1,
                column: "gianhap",
                value: new DateTime(2020, 11, 1, 0, 32, 17, 560, DateTimeKind.Local).AddTicks(5275));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 2,
                column: "gianhap",
                value: new DateTime(2020, 11, 1, 0, 32, 17, 561, DateTimeKind.Local).AddTicks(7760));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 3,
                column: "gianhap",
                value: new DateTime(2020, 11, 1, 0, 32, 17, 561, DateTimeKind.Local).AddTicks(7813));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 4,
                column: "gianhap",
                value: new DateTime(2020, 11, 1, 0, 32, 17, 561, DateTimeKind.Local).AddTicks(7816));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "rate",
                table: "monans");

            migrationBuilder.UpdateData(
                table: "approles",
                keyColumn: "Id",
                keyValue: new Guid("dde4ba55-808e-479f-be8b-72f69913442f"),
                column: "ConcurrencyStamp",
                value: "c2064fb4-8612-4e8a-af16-2bab7d3ddd25");

            migrationBuilder.UpdateData(
                table: "appusers",
                keyColumn: "Id",
                keyValue: new Guid("06e12df2-49ec-4f5a-9d45-fd714ebca62e"),
                columns: new[] { "ConcurrencyStamp", "PasswordHash" },
                values: new object[] { "bc5eb222-a5a6-431a-be20-9896325eedda", "AQAAAAEAACcQAAAAEBxLg830JFPiox/IVKarorsBX+4gqWdZPXycHdyIxlVGElbvpdCe7drS6sHZh613zg==" });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 1,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 10, 31, 22, 3, 18, 523, DateTimeKind.Local).AddTicks(3459) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 2,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 10, 31, 22, 3, 18, 523, DateTimeKind.Local).AddTicks(4508) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 3,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 10, 31, 22, 3, 18, 523, DateTimeKind.Local).AddTicks(4543) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 4,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 10, 31, 22, 3, 18, 523, DateTimeKind.Local).AddTicks(4546) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 5,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 10, 31, 22, 3, 18, 523, DateTimeKind.Local).AddTicks(4550) });

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 1,
                column: "gianhap",
                value: new DateTime(2020, 10, 31, 22, 3, 18, 520, DateTimeKind.Local).AddTicks(9453));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 2,
                column: "gianhap",
                value: new DateTime(2020, 10, 31, 22, 3, 18, 522, DateTimeKind.Local).AddTicks(1940));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 3,
                column: "gianhap",
                value: new DateTime(2020, 10, 31, 22, 3, 18, 522, DateTimeKind.Local).AddTicks(1997));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 4,
                column: "gianhap",
                value: new DateTime(2020, 10, 31, 22, 3, 18, 522, DateTimeKind.Local).AddTicks(2126));
        }
    }
}
