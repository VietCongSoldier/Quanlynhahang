﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Data.Migrations
{
    public partial class _20210111update : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "idFb",
                table: "users",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "approles",
                keyColumn: "Id",
                keyValue: new Guid("dde4ba55-808e-479f-be8b-72f69913442f"),
                column: "ConcurrencyStamp",
                value: "b43b7087-0a30-4950-877a-eb0a8a2a166c");

            migrationBuilder.UpdateData(
                table: "appusers",
                keyColumn: "Id",
                keyValue: new Guid("06e12df2-49ec-4f5a-9d45-fd714ebca62e"),
                columns: new[] { "ConcurrencyStamp", "PasswordHash" },
                values: new object[] { "74d7ec1d-ee64-4018-851f-aae390a78d05", "AQAAAAEAACcQAAAAEBkbOc1KSGvGckeCMUVwcnqDh/KxjkKjfuu/ImFG3AYVjx+j5nu9kSFwyNMexEmkWw==" });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 1,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2021, 1, 11, 16, 22, 57, 243, DateTimeKind.Local).AddTicks(4282) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 2,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2021, 1, 11, 16, 22, 57, 243, DateTimeKind.Local).AddTicks(4935) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 3,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2021, 1, 11, 16, 22, 57, 243, DateTimeKind.Local).AddTicks(4950) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 4,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2021, 1, 11, 16, 22, 57, 243, DateTimeKind.Local).AddTicks(4952) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 5,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2021, 1, 11, 16, 22, 57, 243, DateTimeKind.Local).AddTicks(4954) });

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 1,
                column: "gianhap",
                value: new DateTime(2021, 1, 11, 16, 22, 57, 241, DateTimeKind.Local).AddTicks(7984));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 2,
                column: "gianhap",
                value: new DateTime(2021, 1, 11, 16, 22, 57, 242, DateTimeKind.Local).AddTicks(7972));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 3,
                column: "gianhap",
                value: new DateTime(2021, 1, 11, 16, 22, 57, 242, DateTimeKind.Local).AddTicks(8006));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 4,
                column: "gianhap",
                value: new DateTime(2021, 1, 11, 16, 22, 57, 242, DateTimeKind.Local).AddTicks(8009));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "idFb",
                table: "users");

            migrationBuilder.UpdateData(
                table: "approles",
                keyColumn: "Id",
                keyValue: new Guid("dde4ba55-808e-479f-be8b-72f69913442f"),
                column: "ConcurrencyStamp",
                value: "fcbfd9a6-9dd7-45d4-8d26-8f36bcf202c1");

            migrationBuilder.UpdateData(
                table: "appusers",
                keyColumn: "Id",
                keyValue: new Guid("06e12df2-49ec-4f5a-9d45-fd714ebca62e"),
                columns: new[] { "ConcurrencyStamp", "PasswordHash" },
                values: new object[] { "53021045-c5cf-4925-af50-8ca884969f94", "AQAAAAEAACcQAAAAEHEM30LKlYYJNYwJC4/8Wl4Yw3oQADtYw4V9Y2axnow6nFYDyzQyybvINDT0FZGCiA==" });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 1,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 11, 1, 58, 32, 242, DateTimeKind.Local).AddTicks(340) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 2,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 11, 1, 58, 32, 242, DateTimeKind.Local).AddTicks(2189) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 3,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 11, 1, 58, 32, 242, DateTimeKind.Local).AddTicks(2222) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 4,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 11, 1, 58, 32, 242, DateTimeKind.Local).AddTicks(2227) });

            migrationBuilder.UpdateData(
                table: "monans",
                keyColumn: "id",
                keyValue: 5,
                columns: new[] { "gia", "mota", "ngaynhap" },
                values: new object[] { 20000, "Cập nhật sau", new DateTime(2020, 11, 11, 1, 58, 32, 242, DateTimeKind.Local).AddTicks(2230) });

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 1,
                column: "gianhap",
                value: new DateTime(2020, 11, 11, 1, 58, 32, 239, DateTimeKind.Local).AddTicks(7752));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 2,
                column: "gianhap",
                value: new DateTime(2020, 11, 11, 1, 58, 32, 241, DateTimeKind.Local).AddTicks(1730));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 3,
                column: "gianhap",
                value: new DateTime(2020, 11, 11, 1, 58, 32, 241, DateTimeKind.Local).AddTicks(1787));

            migrationBuilder.UpdateData(
                table: "nhanviens",
                keyColumn: "id",
                keyValue: 4,
                column: "gianhap",
                value: new DateTime(2020, 11, 11, 1, 58, 32, 241, DateTimeKind.Local).AddTicks(1793));
        }
    }
}
