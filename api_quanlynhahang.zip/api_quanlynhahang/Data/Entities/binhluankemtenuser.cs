﻿using System;
using System.Collections.Generic;
using System.Text;

namespace api_quanlynhahang.Entities
{
    public class binhluankemtenuser
    {
        public int id { get; set; }
        public int idsp { get; set; }
        public int iduser { get; set; }
        public DateTime ngaybinhluan { get; set; }
        public string noidung { get; set; }
        public int rate { get; set; }
        public int trangthai { get; set; }
        public string hoten { get; set; }
        public string hinhanh { get; set; }
        public string IdFB { get; set; }
    }
}
