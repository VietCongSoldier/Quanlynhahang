﻿using api_quanlynhahang.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace api_quanlynhahang.Entities
{
    public class monantotal
    {
        public List<monan> monans { get; set; }
        public int total { get; set; }
    }
}
