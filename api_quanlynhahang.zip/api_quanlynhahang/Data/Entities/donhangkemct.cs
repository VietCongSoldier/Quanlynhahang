﻿using api_quanlynhahang.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Entities
{
    public class ctha
    {
        public int id { get; set; }
        public string tenmon { get; set; }
        public int gia { get; set; }
        public int soluong { get; set; }
        public string hinhanh { get; set; }
    }
    public class donhangkemct
    {
        public int id { get; set; }
        public int? idkhach { get; set; }
        public string tenkhach { get; set; }
        public DateTime ngaydat{ get; set; }
        public int tinhtrang { get; set; }
        public string sdtgiao { get; set; }
        public string diachigiao { get; set; }
        public int tongtien { get; set; }
        public List<chitietdonhang> ctdhs { get; set; }
    }
    public class donhangkemha
    {
        public int id { get; set; }
        public int? idkhach { get; set; }
        public string tenkhach { get; set; }
        public int tinhtrang { get; set; }
        public string sdtgiao { get; set; }
        public string diachigiao { get; set; }
        public int tongtien { get; set; }
        public List<ctha> ctdhs { get; set; }
    }
}
