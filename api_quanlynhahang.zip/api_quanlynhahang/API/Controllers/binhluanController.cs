﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using api_quanlynhahang.Entities;
using App.BLL.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class binhluanController : ControllerBase
    {
        private readonly IManagerbinhluanRespo _Respo;
        public binhluanController(IManagerbinhluanRespo respo)
        {
            _Respo = respo;
        }
        [Route("create_binh_luan")]
        [HttpPost]
        public bool create_binh_luan(binhluan bl)
        {
            bl.ngaybinhluan = DateTime.Now;
            return _Respo.create_binh_luan(bl);
        }
        [Route("get_binh_luan_by_id/{id}")]
        [HttpGet]
        public List<binhluankemtenuser> get_binh_luan_by_id(int id)
        {
            return _Respo.get_all_binh_luan(id);
        }
        [Route("get_binh_luan_avg_by_id/{id}")]
        [HttpGet]
        public double get_binh_luan_avg_by_id(int id)
        {
            return _Respo.get_avg_binh_luan(id);
        }
        [Route("get_binh_luan_all")]
        [HttpGet]
        public List<binhluankemtenuser> get_binh_luan_all()
        {
            return _Respo.get_binh_luan_all();
        }
        [Route("an_binh_luan/{id}")]
        [HttpGet]
        public bool an_binh_luan(int id)
        {
            return _Respo.an_binh_luan(id);
        }
        [Route("get_sl_binh_luan")]
        [HttpGet]
        public int get_sl_binh_luan()
        {
            return _Respo.get_sl_binh_luan();
        }
    }
}
