﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using api_quanlynhahang.Entities;
using App.BLL;
using App.BLL.Interfaces;
using Data.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class hoadonController : ControllerBase
    {
        private IManagerhoadonRespo _Respo;
        public hoadonController(IManagerhoadonRespo respo)
        {
            _Respo = respo;
        }
        [Route("create_hoa_don")]
        [HttpPost]
        public bool create_hoa_don([FromBody] donhangkemct donhang)
        {
            donhang.ngaydat = DateTime.Now;
            return _Respo.create_hoa_don(donhang);
        }
        [Route("get_all_don_hang_idkhach/{idkhach}")]
        [HttpGet]
        public List<donhangkemha> get_all_don_hang_idkhach(int idkhach)
        {
            return _Respo.get_all_don_hang_idkhach(idkhach);
        }
        [Route("get_don_hang_idkhach/{id}")]
        [HttpGet]
        public donhangkemha get_don_hang_idkhach(int id)
        {
            return _Respo.get_don_hang_idkhach(id);
        }
        [Route("get_all_don_hang")]
        [HttpGet]
        public List<donhang> get_all_don_hang()
        {
            return _Respo.get_all_don_hang();
        }
        [Route("chuyen_doi_tinh_trang/{id}")]
        [HttpGet]
        public bool chuyendoitinhtrang(int id)
        {
            return _Respo.chuyendoitrangthai(id);
        }
        [Route("get_all_don_hang_tinhtrang/{tinhtrang}")]
        [HttpGet]
        public List<donhangkemha> get_all_don_hang_tinhtrang(int tinhtrang)
        {
            return _Respo.get_all_don_hang_tinhtrang(tinhtrang);
        }
        [Route("tk_mn")]
        [HttpGet]
        public List<int> tk_mn()
        {
            return _Respo.tk_mn();
        }
        [Route("tk_mn_thang")]
        [HttpGet]
        public int tk_mn_thang()
        {
            return _Respo.tk_mn_thang();
        }
        [Route("tk_phan_tram")]
        [HttpGet]
        public double tk_phan_tram()
        {
            return _Respo.tk_phan_tram();
        }
        [Route("tk_mn_ngay_thang")]
        [HttpGet]
        public int tk_mn_ngay_thang()
        {
            return _Respo.tk_mn_ngay_thang();
        }
    }
}
