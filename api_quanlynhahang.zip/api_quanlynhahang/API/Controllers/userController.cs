﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using api_quanlynhahang.Entities;
using App.BLL.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using App.Common;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class userController : ControllerBase
    {
        private IManageruserRespo _Respo;
        public string _path;
        public userController(IManageruserRespo respo, IConfiguration config)
        {
            _Respo = respo;
            _path = config["AppSettings:PATH"];
        }
        public string SaveFileFromBase64String(string RelativePathFileName, string dataFromBase64String)
        {
            if (dataFromBase64String.Contains("base64,"))
            {
                dataFromBase64String = dataFromBase64String.Substring(dataFromBase64String.IndexOf("base64,", 0) + 7);
            }
            return WriteFileToAuthAccessFolder(RelativePathFileName, dataFromBase64String);
        }
        public string WriteFileToAuthAccessFolder(string RelativePathFileName, string base64StringData)
        {
            try
            {
                string result = "";
                string serverRootPathFolder = _path;
                string fullPathFile = $@"{serverRootPathFolder}\{RelativePathFileName}";
                string fullPathFolder = System.IO.Path.GetDirectoryName(fullPathFile);
                if (!Directory.Exists(fullPathFolder))
                    Directory.CreateDirectory(fullPathFolder);
                System.IO.File.WriteAllBytes(fullPathFile, Convert.FromBase64String(base64StringData));
                return result;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        [Route("get_user")]
        [HttpGet]
        public user get_user(string txtemail, string txtpass)
        {
            return _Respo.getUser(txtemail, txtpass);
        }
        [Route("change_form_data_FB")]
        [HttpPost]
        public user change_form_data_FB(user form_data)
        {
            return _Respo.change_form_data_FB(form_data);
        }
        [Route("dangky_user")]
        [HttpPost]
        public AlterResult dangky_user([FromBody] user us)
        {
            return _Respo.dangky_user(us);
        }
        [Route("get_user_id/{id}")]
        [HttpGet]
        public user get_user_id(int id)
        {
            return _Respo.get_user_id(id);
        }
        [Route("change_img/{id}")]
        [HttpPost]
        public ResultPro<user> change_img(int id, [FromBody] user _base)
        {
            if (_base.hinhanh != null)
            {
                var arrData = _base.hinhanh.Split(';');
                if (arrData.Length == 3)
                {
                    var savePath = $@"assets/images/user/{arrData[0]}";
                    _base.hinhanh = arrData[0];
                    SaveFileFromBase64String(savePath, arrData[2]);
                }
            }
            return _Respo.change_img(id, _base.hinhanh);
        }
        [Route("update_profile/{id}")]
        [HttpPut]
        public ResultPro<user> update_profile(int id, [FromBody] user profile)
        {
            return _Respo.update_profile(id, profile);
        }
        [Route("change_pass")]
        [HttpGet]
        public AlterResult update_profile(int id,string pass_new, string pass_old)
        {
            return _Respo.update_profile(id, pass_new, pass_old);
        }
    }
}
