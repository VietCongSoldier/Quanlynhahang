﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.BLL;
using Data.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class dathangController : ControllerBase
    {
        private readonly IManagerdathangRespo _Respo;
        public dathangController(IManagerdathangRespo respo)
        {
            _Respo = respo;
        }
        [Route("dat_hang")]
        [HttpPost]
        public bool dat_hang([FromBody]donhangkemct dh)
        {
            dh.ngaydat = DateTime.Now;
            return _Respo.dathang(dh);
        }
    }
}
