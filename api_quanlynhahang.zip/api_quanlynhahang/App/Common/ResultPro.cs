﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Common
{
    public class ResultPro<T>
    {
        public T result { get; set; }
        public bool alter { get; set; }
    }
}
