﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Common
{
    public class AlterResult
    {
        public string thongbao { get; set; }
        public bool ketqua { get; set; }
    }
}
