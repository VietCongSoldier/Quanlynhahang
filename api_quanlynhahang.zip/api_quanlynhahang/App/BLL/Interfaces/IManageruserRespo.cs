﻿using api_quanlynhahang.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using App.Common;
namespace App.BLL.Interfaces
{
    public interface IManageruserRespo
    {
        public user getUser (string email, string pass);
        public bool disableUser (int id);
        public bool editUser(int id, user kh);
        public bool createUser(user kh);
        public bool changepass(int id);
        public user change_form_data_FB(user form_data);
        public AlterResult dangky_user(user user);
        public user get_user_id(int id);
        public ResultPro<user> change_img(int id, string _base);
        public ResultPro<user> update_profile(int id, user profile);
        public AlterResult update_profile(int id,string pass_new, string pass_old);
    }
}
