﻿using api_quanlynhahang.Entities;
using Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace App.BLL
{
    public interface IManagerdathangRespo
    {
        public bool dathang(donhangkemct ct);
    }
}
