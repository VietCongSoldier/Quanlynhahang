﻿using api_quanlynhahang.Entities;
using Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace App.BLL.Interfaces
{
    public interface IManagerhoadonRespo
    {
        public bool create_hoa_don(donhangkemct donhang);
        public List<donhang> get_all_don_hang();
        public List<donhangkemha> get_all_don_hang_idkhach(int idkhach);
        public bool chuyendoitrangthai(int id);
        public List<donhangkemha> get_all_don_hang_tinhtrang(int tinhtrang);
        public List<int> tk_mn();
        public int tk_mn_thang();
        public int tk_mn_ngay_thang();
        public double tk_phan_tram();
        public donhangkemha get_don_hang_idkhach(int id);
    }
}
