﻿using Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace App.BLL.Interfaces
{
    public interface IManagertintucRespo
    {
        public List<tintuc> get_tin_tuc_noi_bat();
    }
}
