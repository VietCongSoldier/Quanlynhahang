﻿using api_quanlynhahang.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace App.BLL.Interfaces
{
    public interface IManagerbinhluanRespo
    {
        public List<binhluankemtenuser> get_all_binh_luan(int id);
        public bool create_binh_luan(binhluan bl);
        public double get_avg_binh_luan(int id);

        public List<binhluankemtenuser> get_binh_luan_all();
        public bool an_binh_luan(int id);
        public int get_sl_binh_luan();
    }
}
