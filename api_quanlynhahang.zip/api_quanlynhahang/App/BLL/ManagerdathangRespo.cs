﻿using api_quanlynhahang.Entities;
using Data.EF;
using Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace App.BLL
{
    public class ManagerdathangRespo : IManagerdathangRespo
    {
        private readonly CommonContext _context;
        public ManagerdathangRespo(CommonContext context)
        {
            _context = context;
        }

        public bool dathang(donhangkemct ct)
        {
            return true;
        }
    }
}
