﻿using api_quanlynhahang.Entities;
using App.BLL.Interfaces;
using Data.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using App.Common;
using System.IO;


namespace App.BLL
{
    public class ManageruserRespo : IManageruserRespo
    {
        private CommonContext _context;
        public ManageruserRespo(CommonContext context)
        {
            _context = context;
        }
        public bool changepass(int id)
        {
            throw new NotImplementedException();
        }

        public bool createUser(user kh)
        {
            throw new NotImplementedException();
        }

        public bool disableUser(int id)
        {
            throw new NotImplementedException();
        }

        public bool editUser(int id, user kh)
        {
            throw new NotImplementedException();
        }

        public user getUser(string email, string pass)
        {
            user result = _context.users.SingleOrDefault(x => x.email == email && x.password == pass && x.idFb==null);
            if (result == null)
            {
                return null;
            }
            return result;
        }

        public ResultPro<user> change_img(int id,string _base)
        {
            ResultPro<user> kq = new ResultPro<user>();
            try
            {
                user result = _context.users.SingleOrDefault(x => x.id == id);
                if(result == null)
                {
                    kq.result = null;
                    kq.alter = false;
                    return kq;
                }
                result.hinhanh = _base;
                _context.SaveChanges();
                kq.result = _context.users.SingleOrDefault(x => x.id == id);
                kq.alter = true;
                return kq;
            }
            catch(Exception ex)
            {
                kq.result = null;
                kq.alter = false;
                return kq;
            }
        }
        public user change_form_data_FB(user form_data)
        {
            try
            {
                user result = _context.users.SingleOrDefault(x => x.idFb == form_data.idFb);
                if (result == null)
                {
                    form_data.password = "123456";
                    _context.users.Add(form_data);
                }
                else
                {
                    result.hoten = form_data.hoten;
                    result.hinhanh = form_data.hinhanh;
                    result.email = form_data.email;
                }
                _context.SaveChanges();
                user User = _context.users.SingleOrDefault(x => x.idFb == form_data.idFb);
                return User;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public AlterResult dangky_user(user user)
        {
            AlterResult kq = new AlterResult();
            try
            { 
                user us = _context.users.SingleOrDefault(x => x.email == user.email && x.idFb == null);
                if (us != null)
                {
                    kq.thongbao = "Email đã sử dụng rồi!";
                    kq.ketqua = false;
                    return kq;
                }
                else
                {
                    user.hinhanh = "avatar_macdinh.jpg";
                    _context.users.Add(user);
                    _context.SaveChanges();
                    kq.thongbao = "Đăng ký thành công";
                    kq.ketqua = true;
                    return kq;
                }
            }
            catch(Exception ex)
            {
                kq.thongbao = ex.Message;
                kq.ketqua = false;
                return kq;
            }
        }
        public user get_user_id(int id)
        {
            try
            {
                return _context.users.SingleOrDefault(x => x.id == id);
            }
            catch(Exception ex)
            {
                return null;
            }
        }
        public ResultPro<user> update_profile(int id, user profile)
        {
            ResultPro<user> kq = new ResultPro<user>();
            try
            {
                user us = _context.users.SingleOrDefault(x => x.id == id);
                if (us == null)
                {
                    kq.result = null;
                    kq.alter = false;
                    return kq;
                }
                us.hoten = profile.hoten;
                us.diachi = profile.diachi;
                us.ngaysinh = profile.ngaysinh;
                us.sdt = profile.sdt;
                _context.SaveChanges();
                kq.result = _context.users.SingleOrDefault(x => x.id == id);
                kq.alter = true;
                return kq;
            }
            catch (Exception ex)
            {
                kq.result = null;
                kq.alter = false;
                return kq;
            }
        }
        public AlterResult update_profile(int id,string pass_new, string pass_old)
        {
            AlterResult result = new AlterResult();
            try
            {
                user us = _context.users.SingleOrDefault(x => x.id == id);
                if(us == null)
                {
                    result.ketqua = false;
                    result.thongbao = "Tài khoản không tồn tại";
                }
                else
                {
                    if(us.password == pass_old)
                    {
                        if(us.password == pass_new)
                        {
                            result.ketqua = false;
                            result.thongbao = "Mật khẩu mới trùng với cũ. Hãy thử mật khẩu khác.";
                        }
                        else
                        {
                            us.password = pass_new;
                            _context.SaveChanges();
                            result.ketqua = true;
                            result.thongbao = "Đổi mật khẩu thành công";
                        }
                    }
                    else
                    {
                        result.ketqua = false;
                        result.thongbao = "Mật khẩu cũ không chính xác";
                    }
                }
                return result;
            }
            catch(Exception ex)
            {
                result.ketqua = false;
                result.thongbao = ex.Message;
                return result;
            }
        }
    }
}
