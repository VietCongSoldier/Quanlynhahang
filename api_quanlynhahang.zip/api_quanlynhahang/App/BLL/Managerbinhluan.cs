﻿using api_quanlynhahang.Entities;
using App.BLL.Interfaces;
using Data.EF;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace App.BLL
{
    public class Managerbinhluan : IManagerbinhluanRespo
    {
        private readonly CommonContext _Context;
        public Managerbinhluan(CommonContext context)
        {
            _Context = context;
        }

        public bool an_binh_luan(int id)
        {
            try{
                binhluan bl = _Context.binhluans.SingleOrDefault(x => x.id == id);
                if (bl == null)
                {
                    return false;
                }
                else
                {
                    if(bl.trangthai == 1)
                    {
                        bl.trangthai = 2;
                    }
                    else
                    {
                        bl.trangthai = 1;
                    }
                    _Context.SaveChanges();
                    return true;
                }                
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool create_binh_luan(binhluan bl)
        {
            try
            {
                bl.trangthai = 1;
                _Context.binhluans.Add(bl);
                _Context.SaveChanges();
                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }

        public List<binhluankemtenuser> get_all_binh_luan(int id)
        {
            return _Context.binhluans.Join(_Context.users,bl=>bl.iduser,us=>us.id,(bl,us)=>new binhluankemtenuser { 
                id = bl.id,
                idsp = bl.idsp,
                iduser = bl.iduser,
                ngaybinhluan = bl.ngaybinhluan,
                noidung = bl.noidung,
                rate = bl.rate,
                trangthai = bl.trangthai,
                hoten = us.hoten,
                hinhanh = us.hinhanh,
                IdFB = us.idFb
            }).Where(x => x.idsp == id && x.trangthai == 1).ToList();
        }

        public double get_avg_binh_luan(int id)
        {
            var ds = _Context.binhluans.Where(x => x.idsp == id && x.trangthai == 1);
            if(ds.Count() == 0)
            {
                return 0;
            }
            return ds.Average(x => x.rate);
        }
        public int get_sl_binh_luan()
        {
            return _Context.binhluans.ToList().Count();
        }

        public List<binhluankemtenuser> get_binh_luan_all()
        {
            return _Context.binhluans.Join(_Context.users, bl => bl.iduser, us => us.id, (bl, us) => new binhluankemtenuser
            {
                id = bl.id,
                idsp = bl.idsp,
                iduser = bl.iduser,
                ngaybinhluan = bl.ngaybinhluan,
                noidung = bl.noidung,
                rate = bl.rate,
                trangthai = bl.trangthai,
                hoten = us.hoten,
                hinhanh = us.hinhanh,
                IdFB = us.idFb
            }).Where(x => x.rate <= 3).ToList();
        }
    }
}
