﻿using api_quanlynhahang.Entities;
using App.BLL.Interfaces;
using Data.EF;
using Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace App.BLL
{
    public class ManagerhoadonRespo : IManagerhoadonRespo
    {
        private readonly CommonContext _context;
        public ManagerhoadonRespo(CommonContext context)
        {
            _context = context;
        }
        public bool create(donhang dh)
        {
            try
            {
                _context.donhangs.Add(dh);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool create_hoa_don(donhangkemct donhang)
        {
            try
            {
                donhang dh = new donhang();
                dh.idkhach = donhang.idkhach;
                dh.tenkhach = donhang.tenkhach;
                dh.ngaydat = donhang.ngaydat;
                dh.tinhtrang = donhang.tinhtrang;
                dh.sdtgiao = donhang.sdtgiao;
                dh.diachigiao = donhang.diachigiao;
                dh.tongtien = donhang.tongtien;
                if (create(dh))
                {
                    List<donhang> ds = _context.donhangs.ToList();
                    int id = ds[ds.Count() - 1].id;
                    for (int i = 0; i < donhang.ctdhs.Count(); i++)
                    {
                        chitietdonhang ct = new chitietdonhang();
                        ct.iddh = id;
                        ct.idmon = donhang.ctdhs[i].idmon;
                        ct.soluong = donhang.ctdhs[i].soluong;
                        ct.gia = donhang.ctdhs[i].gia;
                        _context.chitietdonhangs.Add(ct);
                    }
                    _context.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public List<donhang> get_all_don_hang()
        {
            return _context.donhangs.ToList();
        }
        public List<donhangkemha> get_all_don_hang_idkhach(int idkhach)
        {
            
            List<donhangkemha> ds = new List<donhangkemha>();
            List<monan> dsmn = _context.monans.ToList();
            List<donhang> ct = _context.donhangs.ToList();
            
            foreach(donhang c in ct)
            {               
                if (c.idkhach == idkhach)
                {
                    donhangkemha a = new donhangkemha();
                    List<ctha> ha = new List<ctha>();
                    a.id = c.id;
                    a.idkhach = c.idkhach;
                    a.tenkhach = c.tenkhach;
                    a.tinhtrang = c.tinhtrang;
                    a.sdtgiao = c.sdtgiao;
                    a.diachigiao = c.diachigiao;
                    a.tongtien = c.tongtien;
                    List<chitietdonhang> b = _context.chitietdonhangs.Where(x => x.iddh == a.id).ToList();
                    foreach(chitietdonhang it in b)
                    {
                        ctha d = new ctha();
                        monan e = dsmn.Where(x => x.id == it.idmon).SingleOrDefault();
                        d.id = it.idmon;
                        d.soluong = it.soluong;
                        d.gia = it.gia;
                        d.hinhanh = e.hinhanh;
                        d.tenmon = e.tenmon;
                        ha.Add(d);
                    }
                    a.ctdhs = ha;
                    ds.Add(a);
                }               
            }
            return ds;
        }
        public bool chuyendoitrangthai(int id)
        {
            try
            {
                _context.donhangs.SingleOrDefault(x => x.id == id).tinhtrang = _context.donhangs.SingleOrDefault(x => x.id == id).tinhtrang + 1;
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public List<donhangkemha> get_all_don_hang_tinhtrang(int tinhtrang)
        {

            List<donhangkemha> ds = new List<donhangkemha>();
            List<monan> dsmn = _context.monans.ToList();
            List<donhang> ct = _context.donhangs.ToList();

            foreach (donhang c in ct)
            {
                if (c.tinhtrang == tinhtrang)
                {
                    donhangkemha a = new donhangkemha();
                    List<ctha> ha = new List<ctha>();
                    a.id = c.id;
                    a.idkhach = c.idkhach;
                    a.tenkhach = c.tenkhach;
                    a.tinhtrang = c.tinhtrang;
                    a.sdtgiao = c.sdtgiao;
                    a.diachigiao = c.diachigiao;
                    a.tongtien = c.tongtien;
                    List<chitietdonhang> b = _context.chitietdonhangs.Where(x => x.iddh == a.id).ToList();
                    foreach (chitietdonhang it in b)
                    {
                        ctha d = new ctha();
                        monan e = dsmn.Where(x => x.id == it.idmon).SingleOrDefault();
                        d.id = it.idmon;
                        d.soluong = it.soluong;
                        d.gia = it.gia;
                        d.hinhanh = e.hinhanh;
                        d.tenmon = e.tenmon;
                        ha.Add(d);
                    }
                    a.ctdhs = ha;
                    ds.Add(a);
                }
            }
            return ds;
        }
        public List<int> tk_mn()
        {
            List<int> ds = new List<int>();
            List<donhang> dsdh = _context.donhangs.ToList();
            for(int i = 1; i < 13; i++)
            {
                int a = dsdh.Where(x => x.ngaydat.Month == i && x.ngaydat.Year == DateTime.Now.Year && x.tinhtrang == 3).Sum(x=>x.tongtien);
                ds.Add(a);
            }
            return ds;
        }
        public int tk_mn_thang()
        {
            return _context.donhangs.Where(x => x.ngaydat.Month ==DateTime.Now.Month && x.ngaydat.Year == DateTime.Now.Year && x.tinhtrang == 3).Sum(x => x.tongtien);
        }
        public int tk_mn_ngay_thang()
        {
            string a = DateTime.Now.ToString();
            return _context.donhangs.Where(x => x.ngaydat.Day == DateTime.Now.Day && x.ngaydat.Month == DateTime.Now.Month && x.ngaydat.Year == DateTime.Now.Year).Sum(x => x.tongtien);
        }
        public double tk_phan_tram()
        {
            List<donhang> ds = _context.donhangs.ToList();
            double a = ds.Where(x => x.tinhtrang == 3).Count()*100;
            return a / ds.Count();
        }
        public donhangkemha get_don_hang_idkhach(int id)
        {
            try
            {
                donhang c = _context.donhangs.SingleOrDefault(x => x.id == id);
                donhangkemha a = new donhangkemha();
                List<ctha> ha = new List<ctha>();
                List<monan> dsmn = _context.monans.ToList();
                a.id = c.id;
                a.idkhach = c.idkhach;
                a.tenkhach = c.tenkhach;
                a.tinhtrang = c.tinhtrang;
                a.sdtgiao = c.sdtgiao;
                a.diachigiao = c.diachigiao;
                a.tongtien = c.tongtien;
                List<chitietdonhang> b = _context.chitietdonhangs.Where(x => x.iddh == a.id).ToList();
                foreach (chitietdonhang it in b)
                {
                    ctha d = new ctha();
                    monan e = dsmn.Where(x => x.id == it.idmon).SingleOrDefault();
                    d.id = it.idmon;
                    d.soluong = it.soluong;
                    d.gia = it.gia;
                    d.hinhanh = e.hinhanh;
                    d.tenmon = e.tenmon;
                    ha.Add(d);
                }
                a.ctdhs = ha;
                return a;
            }
            catch(Exception ex)
            {
                return null;
            }
        }
    }
}
