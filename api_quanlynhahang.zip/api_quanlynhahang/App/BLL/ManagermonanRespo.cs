﻿using api_quanlynhahang.Entities;
using App.BLL.Interfaces;
using Data.EF;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace App.BLL
{
    public class ManagermonanRespo : IManagermonanRespo
    {
        private readonly CommonContext _context;
        public ManagermonanRespo(CommonContext context)
        {
            _context = context;
        }

        public bool Create_mon_an(monan mn)
        {
            try
            {
                _context.Add(mn);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public bool Delete_mon_an(int id)
        {
            try
            {
                monan mn = _context.monans.SingleOrDefault(x => x.id == id);
                if (mn == null)
                {
                    return true;
                }
                else
                {
                    _context.monans.Remove(mn);
                    _context.SaveChanges();
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Edit_mon_an(int id, monan mn)
        {
            try
            {
                monan mon = _context.monans.SingleOrDefault(x => x.id == id);
                if(mon == null)
                {
                    return false;
                }
                mon.tenmon = mn.tenmon;
                mon.donvitinh = mn.donvitinh;
                mon.gia = mn.gia;
                mon.mota = mn.mota;
                mon.hinhanh = mn.hinhanh;
                mon.idloaimon = mn.idloaimon;
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<monan> Get_All_Mon_An()
        {
            return _context.monans.OrderByDescending(x=>x.id).ToList();
        }

        public monan Get_mon_an(int id)
        {
            monan mn = _context.monans.SingleOrDefault(x => x.id == id);
            //mn.loaimon = _context.loaimons.SingleOrDefault(x => x.id == mn.idloaimon);
            return mn;
        }

        public List<monan> Get_Mon_An_New()
        {
            return _context.monans.OrderByDescending(x => x.id).Take(4).Skip(0).ToList();
        }

        public List<monan> Get_Mon_An_Rate()
        {
            List<monan> ds = _context.monans.ToList();
            var dsbl = _context.binhluans;
            foreach(monan mn in ds)
            {
                var dsbl2 = dsbl.Where(x => x.idsp == mn.id && x.trangthai == 1);
                if (dsbl2.Count() == 0)
                {
                    mn.rate = 0;
                }
                else
                {
                    mn.rate = dsbl2.Average(x => x.rate);
                }
            }
            return ds.OrderByDescending(x => x.rate).Take(4).Skip(0).ToList();
        }
        public monantotal Get_Mon_An_Loai(int id, int pageSize, int pageIndex, int order)
        {
            var ds = _context.monans.Where(x => x.idloaimon == id);
            var dsbl = _context.binhluans.Where(x => x.trangthai == 1).ToList();
            foreach (monan item in ds.ToList())
            {
                var a = dsbl.Where(x => x.idsp == item.id).ToList();
                if (a.Count() == 0)
                {
                    item.rate = 0;
                }
                else
                {
                    item.rate = a.Average(x => x.rate);
                }
            }
            switch (order)
            {
                case 1: //mac dinh
                    ds = ds.AsQueryable().OrderBy(x => x.tenmon); 
                    break;
                case 2: // theo ten
                    ds = ds.OrderBy(x => x.tenmon);
                    break;
                case 3: // danh gia
                    //ds = ds.OrderByDescending(x=>x.rate);
                    var ds_xp = ds.ToList();
                    for(int i = 0; i < ds_xp.Count() - 1; i++)
                    {
                        for(int j = i + 1; j < ds_xp.Count(); j++)
                        {
                            if(ds_xp[j].rate > ds_xp[i].rate)
                            {
                                var co_tam = ds_xp[j];
                                ds_xp[j] = ds_xp[i];
                                ds_xp[i] = co_tam;
                            }
                        }
                    }
                    ds = ds_xp.AsQueryable();
                    break;
                case 4: // moi nhat
                    ds = ds.OrderByDescending(x => x.id);
                    break;
                case 5: // thap cao
                    ds = ds.OrderBy(x => x.gia);
                    break;
                case 6: // cao thap
                    ds = ds.OrderByDescending(x => x.gia);
                    break;
            }
            int count = ds.Count();
            int index = (pageSize * (pageIndex - 1));
            ds = ds.Skip(index).Take(pageSize);
            monantotal result = new monantotal();
            result.monans = ds.ToList();
            result.total = count;
            return result;
        }

        public monantotal Get_Mon_An_Loai_Search(int? id, int pageSize, int pageIndex, int order, string search)
        {
            IQueryable<monan> ds;
            if (id == 0)
            {
                if (search == null || search == "")
                {
                    ds = _context.monans;
                }
                else
                {
                    ds = _context.monans.Where(x=>x.tenmon.IndexOf(search) >= 0);
                }
            }
            else
            {
                if(search == null || search =="")
                {
                    ds = _context.monans.Where(x => x.idloaimon == id);
                }
                else
                {
                    ds = _context.monans.Where(x => x.idloaimon == id && x.tenmon.IndexOf(search) >= 0);
                }
            }
            var dsbl = _context.binhluans.Where(x=>x.trangthai == 1).ToList();
            foreach (monan item in ds.ToList())
            {
                var a = dsbl.Where(x => x.idsp == item.id).ToList();
                if (a.Count() == 0)
                {
                    item.rate = 0;
                }
                else
                {
                    item.rate = a.Average(x => x.rate);
                }
            }
            switch (order)
            {
                case 1: //mac dinh
                    ds = ds.OrderBy(x => x.tenmon);
                    break;
                case 2: // theo ten
                    ds = ds.OrderBy(x => x.tenmon);
                    break;
                case 3: // danh gia
                    //ds = ds.OrderByDescending(x => x.id);
                    var ds_xp = ds.ToList();
                    for (int i = 0; i < ds_xp.Count() - 1; i++)
                    {
                        for (int j = i + 1; j < ds_xp.Count(); j++)
                        {
                            if (ds_xp[j].rate > ds_xp[i].rate)
                            {
                                var co_tam = ds_xp[j];
                                ds_xp[j] = ds_xp[i];
                                ds_xp[i] = co_tam;
                            }
                        }
                    }
                    ds = ds_xp.AsQueryable();
                    break;
                case 4: // moi nhat
                    ds = ds.OrderByDescending(x => x.id);
                    break;
                case 5: // thap cao
                    ds = ds.OrderBy(x => x.gia);
                    break;
                case 6: // cao thap
                    ds = ds.OrderByDescending(x => x.gia);
                    break;
            }
            int count = ds.Count();
            int index = (pageSize * (pageIndex - 1));
            ds = ds.Skip(index).Take(pageSize);
            monantotal result = new monantotal();
            result.monans = ds.ToList();
            result.total = count;
            return result;
        }

        public List<monan> Get_Mon_An_Lien_Quan(int id, int idloai)
        {
            return _context.monans.Where(x => x.idloaimon == idloai).OrderByDescending(x=>x.id).Take(4).ToList();
        }
    }
}
