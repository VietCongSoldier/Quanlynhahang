export interface banan{
    id: number;
    soghe: number;
    tinhtrang: number;
    makh: number;
}