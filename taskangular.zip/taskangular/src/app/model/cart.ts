export interface cart
{
    masp : number;
    hinhanh: string;
    soluong: number;
    gia: number;
}