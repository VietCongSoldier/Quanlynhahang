export interface user{
    int:number;
    hoten:string;
    ngaysinh:string;
    sdt:string;
    diachi:string;
    email:string;
    password:string;
    chucvu:string;
    hinhanh:string;
}