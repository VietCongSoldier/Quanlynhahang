import { Component, OnInit ,AfterViewInit, Renderer2} from '@angular/core';

@Component({
  selector: 'app-mainadmin',
  templateUrl: './mainadmin.component.html',
  styleUrls: ['./mainadmin.component.css']
})
export class MainadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
