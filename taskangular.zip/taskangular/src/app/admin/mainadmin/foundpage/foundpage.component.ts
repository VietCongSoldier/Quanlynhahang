import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foundpage',
  templateUrl: './foundpage.component.html',
  styleUrls: ['./foundpage.component.css']
})
export class FoundpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
