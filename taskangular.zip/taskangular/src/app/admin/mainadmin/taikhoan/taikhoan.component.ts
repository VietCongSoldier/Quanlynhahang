import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-taikhoan',
  templateUrl: './taikhoan.component.html',
  styleUrls: ['./taikhoan.component.css']
})
export class TaikhoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
