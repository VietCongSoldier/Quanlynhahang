import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-phieugoimon',
  templateUrl: './phieugoimon.component.html',
  styleUrls: ['./phieugoimon.component.css']
})
export class PhieugoimonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
