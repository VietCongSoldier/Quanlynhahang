import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-khachhang',
  templateUrl: './khachhang.component.html',
  styleUrls: ['./khachhang.component.css']
})
export class KhachhangComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
