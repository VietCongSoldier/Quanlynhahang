import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binhluan',
  templateUrl: './binhluan.component.html',
  styleUrls: ['./binhluan.component.css']
})
export class BinhluanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
