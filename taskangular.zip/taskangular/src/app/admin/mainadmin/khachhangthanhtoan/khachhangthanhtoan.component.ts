import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-khachhangthanhtoan',
  templateUrl: './khachhangthanhtoan.component.html',
  styleUrls: ['./khachhangthanhtoan.component.css']
})
export class KhachhangthanhtoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
