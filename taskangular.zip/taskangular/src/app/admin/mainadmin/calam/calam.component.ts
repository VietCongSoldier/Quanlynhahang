import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calam',
  templateUrl: './calam.component.html',
  styleUrls: ['./calam.component.css']
})
export class CalamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
