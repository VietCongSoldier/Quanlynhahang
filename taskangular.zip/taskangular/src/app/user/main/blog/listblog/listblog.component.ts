import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listblog',
  templateUrl: './listblog.component.html',
  styleUrls: ['./listblog.component.css']
})
export class ListblogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
