import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailblog',
  templateUrl: './detailblog.component.html',
  styleUrls: ['./detailblog.component.css']
})
export class DetailblogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
